import { useEffect, useState } from "react";
import api from "../api";
import Navbar from "../components/Navbar";

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [departments, setDepartments] = useState([]);
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);

  // form state
  const [deptName, setDeptName] = useState("");
  const [userForm, setUserForm] = useState({ name: "", email: "", password: "", role: "employee", department_id: "", manager_id: "" });
  const [projectForm, setProjectForm] = useState({ code: "", name: "" });
  const [assignForm, setAssignForm] = useState({ user_id: "", project_id: "" });
  const [message, setMessage] = useState("");

  const loadAll = async () => {
    const [s, d, u, p] = await Promise.all([
      api.get("/admin/dashboard"),
      api.get("/admin/departments"),
      api.get("/admin/users"),
      api.get("/admin/projects"),
    ]);
    setStats(s.data);
    setDepartments(d.data);
    setUsers(u.data);
    setProjects(p.data);
  };

  useEffect(() => { loadAll(); }, []);

  const showMsg = (text) => { setMessage(text); setTimeout(() => setMessage(""), 3000); };

  const createDepartment = async (e) => {
    e.preventDefault();
    try {
      await api.post("/admin/departments", { name: deptName });
      setDeptName("");
      showMsg("Department created");
      loadAll();
    } catch (err) { showMsg(err.response?.data?.detail || "Error"); }
  };

  const createUser = async (e) => {
    e.preventDefault();
    try {
      await api.post("/admin/users", {
        ...userForm,
        department_id: userForm.department_id ? Number(userForm.department_id) : null,
        manager_id: userForm.manager_id ? Number(userForm.manager_id) : null,
      });
      setUserForm({ name: "", email: "", password: "", role: "employee", department_id: "", manager_id: "" });
      showMsg("User created");
      loadAll();
    } catch (err) { showMsg(err.response?.data?.detail || "Error"); }
  };

  const createProject = async (e) => {
    e.preventDefault();
    try {
      await api.post("/admin/projects", projectForm);
      setProjectForm({ code: "", name: "" });
      showMsg("Project created");
      loadAll();
    } catch (err) { showMsg(err.response?.data?.detail || "Error"); }
  };

  const assignProject = async (e) => {
    e.preventDefault();
    try {
      await api.post("/admin/assignments", {
        user_id: Number(assignForm.user_id),
        project_id: Number(assignForm.project_id),
      });
      showMsg("Assigned");
    } catch (err) { showMsg(err.response?.data?.detail || "Error"); }
  };

  return (
    <div>
      <Navbar />
      <div style={{ padding: "20px" }}>
        <h2>Admin Dashboard</h2>
        {message && <p style={{ color: "green" }}>{message}</p>}

        {stats && (
          <div style={styles.statsRow}>
            <div style={styles.statBox}>Users: {stats.total_users}</div>
            <div style={styles.statBox}>Projects: {stats.total_projects}</div>
            <div style={styles.statBox}>Active Projects: {stats.active_projects}</div>
            <div style={styles.statBox}>Departments: {stats.total_departments}</div>
          </div>
        )}

        <div style={styles.grid}>
          <section style={styles.card}>
            <h3>Create Department</h3>
            <form onSubmit={createDepartment} style={styles.form}>
              <input placeholder="Department name" value={deptName} onChange={(e) => setDeptName(e.target.value)} required />
              <button type="submit">Add</button>
            </form>
            <ul>{departments.map((d) => <li key={d.id}>{d.id}: {d.name}</li>)}</ul>
          </section>

          <section style={styles.card}>
            <h3>Create Project</h3>
            <form onSubmit={createProject} style={styles.form}>
              <input placeholder="Code e.g. PRJ-003" value={projectForm.code} onChange={(e) => setProjectForm({ ...projectForm, code: e.target.value })} required />
              <input placeholder="Project name" value={projectForm.name} onChange={(e) => setProjectForm({ ...projectForm, name: e.target.value })} required />
              <button type="submit">Add</button>
            </form>
            <ul>{projects.map((p) => <li key={p.id}>{p.id}: {p.code} - {p.name}</li>)}</ul>
          </section>

          <section style={styles.card}>
            <h3>Create User</h3>
            <form onSubmit={createUser} style={styles.form}>
              <input placeholder="Name" value={userForm.name} onChange={(e) => setUserForm({ ...userForm, name: e.target.value })} required />
              <input placeholder="Email" type="email" value={userForm.email} onChange={(e) => setUserForm({ ...userForm, email: e.target.value })} required />
              <input placeholder="Password" type="password" value={userForm.password} onChange={(e) => setUserForm({ ...userForm, password: e.target.value })} required />
              <select value={userForm.role} onChange={(e) => setUserForm({ ...userForm, role: e.target.value })}>
                <option value="employee">Employee</option>
                <option value="manager">Manager</option>
                <option value="admin">Admin</option>
              </select>
              <select value={userForm.department_id} onChange={(e) => setUserForm({ ...userForm, department_id: e.target.value })}>
                <option value="">No department</option>
                {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
              <select value={userForm.manager_id} onChange={(e) => setUserForm({ ...userForm, manager_id: e.target.value })}>
                <option value="">No manager</option>
                {users.filter(u => u.role === "manager").map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
              <button type="submit">Add</button>
            </form>
          </section>

          <section style={styles.card}>
            <h3>Assign Project to User</h3>
            <form onSubmit={assignProject} style={styles.form}>
              <select value={assignForm.user_id} onChange={(e) => setAssignForm({ ...assignForm, user_id: e.target.value })} required>
                <option value="">Select user</option>
                {users.map((u) => <option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}
              </select>
              <select value={assignForm.project_id} onChange={(e) => setAssignForm({ ...assignForm, project_id: e.target.value })} required>
                <option value="">Select project</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.code}</option>)}
              </select>
              <button type="submit">Assign</button>
            </form>
          </section>
        </div>

        <section style={{ marginTop: "20px" }}>
          <h3>All Users</h3>
          <table style={styles.table}>
            <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Active</th></tr></thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}><td>{u.id}</td><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td>{u.is_active ? "Yes" : "No"}</td></tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </div>
  );
}

const styles = {
  statsRow: { display: "flex", gap: "15px", marginBottom: "20px" },
  statBox: { padding: "15px", background: "#f0f0f0", borderRadius: "6px" },
  grid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" },
  card: { border: "1px solid #ccc", borderRadius: "6px", padding: "15px" },
  form: { display: "flex", flexDirection: "column", gap: "8px", maxWidth: "300px" },
  table: { width: "100%", borderCollapse: "collapse" },
};
