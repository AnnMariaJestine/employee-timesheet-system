import { useEffect, useState } from "react";
import api from "../api";
import Navbar from "../components/Navbar";

export default function EmployeeDashboard() {
  const [entries, setEntries] = useState([]);
  const [stats, setStats] = useState(null);
  const [projects, setProjects] = useState([]);
  const [form, setForm] = useState({ project_id: "", work_date: "", hours: "" });
  const [editingId, setEditingId] = useState(null);
  const [message, setMessage] = useState("");

  const load = async () => {
    const [e, s, p] = await Promise.all([
      api.get("/employee/timesheets"),
      api.get("/employee/dashboard"),
      api.get("/employee/projects"),
    ]);
    setEntries(e.data);
    setStats(s.data);
    setProjects(p.data);
  };

  useEffect(() => { load(); }, []);

  const showMsg = (text) => { setMessage(text); setTimeout(() => setMessage(""), 3000); };

  const handleSubmitForm = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await api.put(`/employee/timesheets/${editingId}`, {
          project_id: Number(form.project_id),
          work_date: form.work_date,
          hours: Number(form.hours),
        });
        showMsg("Entry updated");
        setEditingId(null);
      } else {
        await api.post("/employee/timesheets", {
          project_id: Number(form.project_id),
          work_date: form.work_date,
          hours: Number(form.hours),
        });
        showMsg("Entry created as draft");
      }
      setForm({ project_id: "", work_date: "", hours: "" });
      load();
    } catch (err) {
      showMsg(err.response?.data?.detail || "Error");
    }
  };

  const editEntry = (entry) => {
    setEditingId(entry.id);
    setForm({ project_id: entry.project_id, work_date: entry.work_date, hours: entry.hours });
  };

  const submitEntry = async (id) => {
    try {
      await api.post(`/employee/timesheets/${id}/submit`);
      showMsg("Submitted for approval");
      load();
    } catch (err) {
      showMsg(err.response?.data?.detail || "Error");
    }
  };

  return (
    <div>
      <Navbar />
      <div style={{ padding: "20px" }}>
        <h2>Employee Dashboard</h2>
        {message && <p style={{ color: "green" }}>{message}</p>}

        {stats && (
          <div style={styles.statsRow}>
            <div style={styles.statBox}>Draft: {stats.draft}</div>
            <div style={styles.statBox}>Submitted: {stats.submitted}</div>
            <div style={styles.statBox}>Approved: {stats.approved}</div>
            <div style={styles.statBox}>Rejected: {stats.rejected}</div>
          </div>
        )}

        <section style={styles.card}>
          <h3>{editingId ? "Edit Entry" : "New Timesheet Entry"}</h3>
          <form onSubmit={handleSubmitForm} style={styles.form}>
            <select value={form.project_id} onChange={(e) => setForm({ ...form, project_id: e.target.value })} required>
              <option value="">Select project</option>
              {projects.map((p) => <option key={p.id} value={p.id}>{p.code} - {p.name}</option>)}
            </select>
            <input type="date" value={form.work_date} onChange={(e) => setForm({ ...form, work_date: e.target.value })} required />
            <input type="number" step="0.5" min="0.5" max="12" placeholder="Hours" value={form.hours} onChange={(e) => setForm({ ...form, hours: e.target.value })} required />
            <button type="submit">{editingId ? "Save Changes" : "Create Draft"}</button>
            {editingId && <button type="button" onClick={() => { setEditingId(null); setForm({ project_id: "", work_date: "", hours: "" }); }}>Cancel</button>}
          </form>
        </section>

        <section style={{ marginTop: "20px" }}>
          <h3>My Entries</h3>
          <table style={styles.table}>
            <thead>
              <tr><th>Date</th><th>Project</th><th>Hours</th><th>Status</th><th>Reject Reason</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {entries.map((e) => (
                <tr key={e.id}>
                  <td>{e.work_date}</td>
                  <td>{projects.find(p => p.id === e.project_id)?.code || e.project_id}</td>
                  <td>{e.hours}</td>
                  <td>{e.status}</td>
                  <td>{e.reject_comment || "-"}</td>
                  <td>
                    {(e.status === "draft" || e.status === "rejected") && (
                      <>
                        <button onClick={() => editEntry(e)}>Edit</button>{" "}
                        <button onClick={() => submitEntry(e.id)}>Submit</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </div>
  );
}

const styles = {
  statsRow: { display: "flex", gap: "15px", marginBottom: "20px" },
  statBox: { padding: "15px", background: "#f0f0f0", borderRadius: "6px" },
  card: { border: "1px solid #ccc", borderRadius: "6px", padding: "15px", maxWidth: "400px" },
  form: { display: "flex", flexDirection: "column", gap: "8px" },
  table: { width: "100%", borderCollapse: "collapse" },
};
