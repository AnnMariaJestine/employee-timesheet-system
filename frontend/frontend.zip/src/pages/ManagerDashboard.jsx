import { useEffect, useState } from "react";
import api from "../api";
import Navbar from "../components/Navbar";

export default function ManagerDashboard() {
  const [entries, setEntries] = useState([]);
  const [stats, setStats] = useState(null);
  const [filter, setFilter] = useState("submitted");
  const [message, setMessage] = useState("");
  const [rejectingId, setRejectingId] = useState(null);
  const [rejectComment, setRejectComment] = useState("");

  const load = async () => {
    const [e, s] = await Promise.all([
      api.get("/manager/timesheets", { params: filter ? { status: filter } : {} }),
      api.get("/manager/dashboard"),
    ]);
    setEntries(e.data);
    setStats(s.data);
  };

  useEffect(() => { load(); }, [filter]);

  const showMsg = (text) => { setMessage(text); setTimeout(() => setMessage(""), 3000); };

  const approve = async (id) => {
    try {
      await api.post(`/manager/timesheets/${id}/approve`);
      showMsg("Approved");
      load();
    } catch (err) { showMsg(err.response?.data?.detail || "Error"); }
  };

  const confirmReject = async (id) => {
    if (!rejectComment.trim()) { showMsg("A comment is required to reject"); return; }
    try {
      await api.post(`/manager/timesheets/${id}/reject`, { comment: rejectComment });
      showMsg("Rejected");
      setRejectingId(null);
      setRejectComment("");
      load();
    } catch (err) { showMsg(err.response?.data?.detail || "Error"); }
  };

  return (
    <div>
      <Navbar />
      <div style={{ padding: "20px" }}>
        <h2>Manager Dashboard</h2>
        {message && <p style={{ color: "green" }}>{message}</p>}

        {stats && (
          <div style={styles.statsRow}>
            <div style={styles.statBox}>Team Size: {stats.team_size}</div>
            <div style={styles.statBox}>Pending Review: {stats.pending_review}</div>
            <div style={styles.statBox}>Approved: {stats.approved}</div>
            <div style={styles.statBox}>Rejected: {stats.rejected}</div>
          </div>
        )}

        <div style={{ marginBottom: "10px" }}>
          Filter:{" "}
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="submitted">Submitted (pending)</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
            <option value="">All</option>
          </select>
        </div>

        <table style={styles.table}>
          <thead>
            <tr><th>Employee ID</th><th>Date</th><th>Project ID</th><th>Hours</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {entries.map((e) => (
              <tr key={e.id}>
                <td>{e.user_id}</td>
                <td>{e.work_date}</td>
                <td>{e.project_id}</td>
                <td>{e.hours}</td>
                <td>{e.status}</td>
                <td>
                  {e.status === "submitted" && (
                    rejectingId === e.id ? (
                      <>
                        <input
                          placeholder="Rejection reason"
                          value={rejectComment}
                          onChange={(ev) => setRejectComment(ev.target.value)}
                        />
                        <button onClick={() => confirmReject(e.id)}>Confirm Reject</button>
                        <button onClick={() => { setRejectingId(null); setRejectComment(""); }}>Cancel</button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => approve(e.id)}>Approve</button>{" "}
                        <button onClick={() => setRejectingId(e.id)}>Reject</button>
                      </>
                    )
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const styles = {
  statsRow: { display: "flex", gap: "15px", marginBottom: "20px" },
  statBox: { padding: "15px", background: "#f0f0f0", borderRadius: "6px" },
  table: { width: "100%", borderCollapse: "collapse" },
};
