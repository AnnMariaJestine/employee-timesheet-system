import { useNavigate } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();
  const name = localStorage.getItem("name");
  const role = localStorage.getItem("role");

  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  return (
    <div style={styles.bar}>
      <span>{name} ({role})</span>
      <button onClick={logout} style={styles.button}>Log Out</button>
    </div>
  );
}

const styles = {
  bar: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "10px 20px", background: "#222", color: "#fff",
  },
  button: { padding: "6px 12px", cursor: "pointer" },
};
