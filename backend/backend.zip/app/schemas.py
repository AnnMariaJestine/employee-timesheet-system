from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, EmailStr


# ---- Auth ----
class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    name: str
    user_id: int


# ---- Department ----
class DepartmentCreate(BaseModel):
    name: str


class DepartmentOut(BaseModel):
    id: int
    name: str
    class Config:
        from_attributes = True


# ---- User ----
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str  # admin / employee / manager
    department_id: Optional[int] = None
    manager_id: Optional[int] = None


class UserOut(BaseModel):
    id: int
    name: str
    email: str
    role: str
    department_id: Optional[int]
    manager_id: Optional[int]
    is_active: bool
    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    name: Optional[str] = None
    department_id: Optional[int] = None
    manager_id: Optional[int] = None
    is_active: Optional[bool] = None


# ---- Project ----
class ProjectCreate(BaseModel):
    code: str
    name: str


class ProjectOut(BaseModel):
    id: int
    code: str
    name: str
    is_active: bool
    class Config:
        from_attributes = True


# ---- Project Assignment ----
class AssignmentCreate(BaseModel):
    user_id: int
    project_id: int


# ---- Timesheet ----
class TimesheetCreate(BaseModel):
    project_id: int
    work_date: date
    hours: float


class TimesheetUpdate(BaseModel):
    project_id: Optional[int] = None
    work_date: Optional[date] = None
    hours: Optional[float] = None


class TimesheetOut(BaseModel):
    id: int
    user_id: int
    project_id: int
    work_date: date
    hours: float
    status: str
    reject_comment: Optional[str]
    created_at: datetime
    class Config:
        from_attributes = True


class RejectRequest(BaseModel):
    comment: str
