from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from .. import models, schemas, auth
from ..database import get_db

router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(auth.require_role("admin"))])


# ---- Departments ----
@router.post("/departments", response_model=schemas.DepartmentOut)
def create_department(payload: schemas.DepartmentCreate, db: Session = Depends(get_db)):
    dept = models.Department(name=payload.name)
    db.add(dept)
    db.commit()
    db.refresh(dept)
    return dept


@router.get("/departments", response_model=List[schemas.DepartmentOut])
def list_departments(db: Session = Depends(get_db)):
    return db.query(models.Department).all()


# ---- Users ----
@router.post("/users", response_model=schemas.UserOut)
def create_user(payload: schemas.UserCreate, db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already exists")
    if payload.role not in ("admin", "employee", "manager"):
        raise HTTPException(status_code=400, detail="Invalid role")

    user = models.User(
        name=payload.name,
        email=payload.email,
        password_hash=auth.hash_password(payload.password),
        role=payload.role,
        department_id=payload.department_id,
        manager_id=payload.manager_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.get("/users", response_model=List[schemas.UserOut])
def list_users(db: Session = Depends(get_db)):
    return db.query(models.User).all()


@router.put("/users/{user_id}", response_model=schemas.UserOut)
def update_user(user_id: int, payload: schemas.UserUpdate, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    for field, value in payload.dict(exclude_unset=True).items():
        setattr(user, field, value)

    db.commit()
    db.refresh(user)
    return user


# ---- Projects ----
@router.post("/projects", response_model=schemas.ProjectOut)
def create_project(payload: schemas.ProjectCreate, db: Session = Depends(get_db)):
    if db.query(models.Project).filter(models.Project.code == payload.code).first():
        raise HTTPException(status_code=400, detail="Project code already exists")
    project = models.Project(code=payload.code, name=payload.name)
    db.add(project)
    db.commit()
    db.refresh(project)
    return project


@router.get("/projects", response_model=List[schemas.ProjectOut])
def list_projects(db: Session = Depends(get_db)):
    return db.query(models.Project).all()


@router.put("/projects/{project_id}/deactivate", response_model=schemas.ProjectOut)
def deactivate_project(project_id: int, db: Session = Depends(get_db)):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    project.is_active = False
    db.commit()
    db.refresh(project)
    return project


# ---- Project Assignments ----
@router.post("/assignments")
def assign_project(payload: schemas.AssignmentCreate, db: Session = Depends(get_db)):
    exists = db.query(models.ProjectAssignment).filter(
        models.ProjectAssignment.user_id == payload.user_id,
        models.ProjectAssignment.project_id == payload.project_id,
    ).first()
    if exists:
        raise HTTPException(status_code=400, detail="Already assigned")

    assignment = models.ProjectAssignment(user_id=payload.user_id, project_id=payload.project_id)
    db.add(assignment)
    db.commit()
    return {"message": "Assigned successfully"}


# ---- Dashboard ----
@router.get("/dashboard")
def admin_dashboard(db: Session = Depends(get_db)):
    return {
        "total_users": db.query(models.User).count(),
        "total_projects": db.query(models.Project).count(),
        "active_projects": db.query(models.Project).filter(models.Project.is_active == True).count(),
        "total_departments": db.query(models.Department).count(),
    }
